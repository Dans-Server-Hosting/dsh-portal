Mock export for the portal tests: world.usda only (the real zip also holds terrain.usdc).
